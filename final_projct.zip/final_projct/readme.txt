Select New Team to create a new team or select open team to open an existing team from Manage Team menu.
Select 11 players from categories(BATSMEN,BOWLER,ALLROUNDER,WICKETKEEPER).
The Points are limited to 1000.You can not select more than that.
Only 1 Wicketkeeper is allowed to select.
Select save team to save the data of your team.
Go Ahead and select evaluate team to calculate points of your fantasy cricket team(from menubar).
Select Quit to quit game.


Points Rules:
Batting
● 1 point for 2 runs scored
● Additional 5 points for half century
● Additional 10 points for century
● 2 points for strike rate (runs/balls faced) of 80-100
● Additional 4 points for strike rate>100
● 1 point for hitting a boundary (four) and 2 points for over boundary (six)
Bowling
● 10 points for each wicket
● Additional 5 points for three wickets per innings
● Additional 10 points for 5 wickets or more in innings
● 4 points for economy rate (runs given per over) between 3.5 and 4.5
● 7 points for economy rate between 2 and 3.5
● 10 points for economy rate less than 2
Fielding
● 10 points each for catch/stumping/run out
